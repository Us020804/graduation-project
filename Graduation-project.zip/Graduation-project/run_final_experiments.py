import argparse
import json
import subprocess
import sys
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent

EXPERIMENTS = [
    {
        "scenario": "Normal",
        "algorithm": "A*",
        "script": "train_astar.py",
        "output": "astar_rewards.json",
        "requires": [],
    },
    {
        "scenario": "Normal",
        "algorithm": "Q-learning",
        "script": "evaluate_q_learning.py",
        "output": "q_learning_eval_rewards.json",
        "requires": ["q_learning_q_table.pkl"],
    },
    {
        "scenario": "Normal",
        "algorithm": "DQN",
        "script": "evaluate_dqn.py",
        "output": "dqn_eval_rewards.json",
        "requires": ["dqn_best.pth"],
    },
    {
        "scenario": "Peak Canteen",
        "algorithm": "A*",
        "script": "train_astar_peak_canteen.py",
        "output": "astar_peak_canteen_rewards.json",
        "requires": [],
    },
    {
        "scenario": "Peak Canteen",
        "algorithm": "Q-learning",
        "script": "evaluate_q_learning_peak_canteen.py",
        "output": "q_learning_peak_canteen_eval_rewards.json",
        "requires": ["q_learning_peak_canteen_q_table.pkl"],
    },
    {
        "scenario": "Peak Canteen",
        "algorithm": "DQN",
        "script": "evaluate_dqn_peak_canteen.py",
        "output": "dqn_peak_canteen_eval_rewards.json",
        "requires": ["dqn_peak_canteen_best.pth"],
    },
]


def load_rewards(path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def print_average(experiment):
    output_path = BASE_DIR / experiment["output"]
    if not output_path.exists():
        print(f"  No output file: {experiment['output']}")
        return

    rewards = load_rewards(output_path)
    avg_reward = sum(rewards) / len(rewards)
    print(
        f"  {experiment['scenario']} - {experiment['algorithm']}: "
        f"episodes={len(rewards)}, average={avg_reward:.2f}"
    )


def validate_inputs(experiment):
    missing = []
    script_path = BASE_DIR / experiment["script"]
    if not script_path.exists():
        missing.append(experiment["script"])

    for filename in experiment["requires"]:
        if not (BASE_DIR / filename).exists():
            missing.append(filename)

    return missing


def run_experiment(experiment, rerun=False):
    label = f"{experiment['scenario']} - {experiment['algorithm']}"
    output_path = BASE_DIR / experiment["output"]

    missing = validate_inputs(experiment)
    if missing:
        print(f"[MISSING] {label}: {', '.join(missing)}")
        return False

    if output_path.exists() and not rerun:
        print(f"[SKIP] {label}: found {experiment['output']}")
        print_average(experiment)
        return True

    print(f"[RUN] {label}: python {experiment['script']}")
    result = subprocess.run(
        [sys.executable, experiment["script"]],
        cwd=BASE_DIR,
        check=False,
    )

    if result.returncode != 0:
        print(f"[FAILED] {label}: exit code {result.returncode}")
        return False

    print_average(experiment)
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Run final evaluation experiments using existing scripts."
    )
    parser.add_argument(
        "--rerun",
        action="store_true",
        help="Run experiments even when the expected JSON output already exists.",
    )
    args = parser.parse_args()

    print("Final experiment runner")
    print("Default behavior: skip experiments with existing JSON outputs.")
    print()

    ok_count = 0
    for experiment in EXPERIMENTS:
        if run_experiment(experiment, rerun=args.rerun):
            ok_count += 1

    print()
    print(f"Completed or skipped successfully: {ok_count}/{len(EXPERIMENTS)}")
    if ok_count != len(EXPERIMENTS):
        sys.exit(1)


if __name__ == "__main__":
    main()
