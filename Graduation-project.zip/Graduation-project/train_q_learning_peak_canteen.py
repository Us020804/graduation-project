from env import UAVEnv
from q_learning import QLearningAgent
import json


ACTIONS = ['UP', 'DOWN', 'LEFT', 'RIGHT', 'STAY']

env = UAVEnv(
    sumocfg_file="jnu_peak_canteen.sumocfg",
    uav_start=(1600, 1600),
    uav_radius=200,
    step_size=20,
    x_min=0,
    x_max=2938,
    y_min=0,
    y_max=2318,
    max_steps=50,
    gui=False,
    move_cost=0.1
)

agent = QLearningAgent(
    actions=ACTIONS,
    alpha=0.1,
    gamma=0.9,
    epsilon=0.1
)

episodes = 30
reward_history = []

print("Current training: Q-learning on peak canteen traffic")

for episode in range(episodes):
    state = env.reset()
    total_reward = 0

    start_covered = env.count_covered_vehicles()
    print(
        f"Episode {episode + 1} start state {state}, "
        f"start covered vehicles {start_covered}"
    )

    for step in range(env.max_steps):
        action = agent.choose_action(state)
        next_state, reward, done = env.step(action)

        agent.learn(state, action, reward, next_state, done)

        total_reward += reward
        state = next_state

        if episode == 0 and step < 10:
            print(
                f"  step={step + 1}, action={action}, "
                f"next_state={next_state}, reward={reward}, done={done}"
            )

        if done:
            break

    reward_history.append(total_reward)
    print(f"Episode {episode + 1}: total reward = {total_reward:.2f}")

env.close_sumo()

print("Training completed")
print("Q-table size:", len(agent.q_table))
print(reward_history)

with open("q_learning_peak_canteen_rewards.json", "w", encoding="utf-8") as f:
    json.dump(reward_history, f, ensure_ascii=False)

agent.save_q_table("q_learning_peak_canteen_q_table.pkl")

print("Saved q_learning_peak_canteen_rewards.json")
print("Saved q_learning_peak_canteen_q_table.pkl")
