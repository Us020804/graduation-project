import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


BASE_DIR = Path(__file__).resolve().parent
SUMMARY_CSV = BASE_DIR / "final_metrics_summary.csv"
ALGORITHMS = ["A*", "Q-learning", "DQN"]
SCENARIOS = ["Normal", "Peak Canteen"]


def load_summary():
    with SUMMARY_CSV.open("r", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def value_for(rows, scenario, algorithm, field):
    for row in rows:
        if row["场景"] == scenario and row["算法"] == algorithm:
            return float(row[field])
    raise KeyError(f"Missing {scenario} - {algorithm} - {field}")


def save_bar(rows, scenario, field, ylabel, title, output_name):
    values = [value_for(rows, scenario, algorithm, field) for algorithm in ALGORITHMS]

    plt.figure(figsize=(8, 5))
    bars = plt.bar(ALGORITHMS, values, color=["#4C78A8", "#F58518", "#54A24B"])
    plt.title(title)
    plt.xlabel("Algorithm")
    plt.ylabel(ylabel)
    plt.grid(axis="y", linestyle="--", alpha=0.4)

    for bar, value in zip(bars, values):
        label = f"{value:.4f}" if field == "平均覆盖率" else f"{value:.2f}"
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            label,
            ha="center",
            va="bottom",
            fontsize=10,
        )

    plt.tight_layout()
    plt.savefig(BASE_DIR / output_name, dpi=300)
    plt.close()
    print(f"Saved {output_name}")


def save_grouped_bar(rows, field, ylabel, title, output_name):
    x_positions = list(range(len(ALGORITHMS)))
    width = 0.35

    plt.figure(figsize=(9, 5.5))
    for offset, scenario, color in [
        (-width / 2, "Normal", "#4C78A8"),
        (width / 2, "Peak Canteen", "#F58518"),
    ]:
        values = [value_for(rows, scenario, algorithm, field) for algorithm in ALGORITHMS]
        plt.bar(
            [x + offset for x in x_positions],
            values,
            width=width,
            label=scenario,
            color=color,
        )

    plt.xticks(x_positions, ALGORITHMS)
    plt.title(title)
    plt.xlabel("Algorithm")
    plt.ylabel(ylabel)
    plt.legend()
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(BASE_DIR / output_name, dpi=300)
    plt.close()
    print(f"Saved {output_name}")


def main():
    rows = load_summary()

    save_bar(
        rows,
        "Normal",
        "平均奖励",
        "Average Total Reward",
        "Normal Scenario Average Reward",
        "metrics_normal_average_reward.png",
    )
    save_bar(
        rows,
        "Normal",
        "平均覆盖车辆数",
        "Average Covered Vehicles",
        "Normal Scenario Average Covered Vehicles",
        "metrics_normal_average_covered.png",
    )
    save_bar(
        rows,
        "Normal",
        "平均覆盖率",
        "Average Coverage Rate",
        "Normal Scenario Average Coverage Rate",
        "metrics_normal_average_coverage_rate.png",
    )
    save_bar(
        rows,
        "Peak Canteen",
        "平均奖励",
        "Average Total Reward",
        "Peak Canteen Scenario Average Reward",
        "metrics_peak_average_reward.png",
    )
    save_bar(
        rows,
        "Peak Canteen",
        "平均覆盖车辆数",
        "Average Covered Vehicles",
        "Peak Canteen Scenario Average Covered Vehicles",
        "metrics_peak_average_covered.png",
    )
    save_bar(
        rows,
        "Peak Canteen",
        "平均覆盖率",
        "Average Coverage Rate",
        "Peak Canteen Scenario Average Coverage Rate",
        "metrics_peak_average_coverage_rate.png",
    )
    save_grouped_bar(
        rows,
        "平均覆盖率",
        "Average Coverage Rate",
        "Normal vs Peak Canteen Coverage Rate",
        "metrics_normal_vs_peak_coverage_rate.png",
    )


if __name__ == "__main__":
    main()
