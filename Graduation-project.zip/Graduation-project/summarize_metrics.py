import csv
import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_CSV = BASE_DIR / "final_metrics_summary.csv"

METRIC_FILES = [
    ("Normal", "A*", "astar_metrics.json"),
    ("Normal", "Q-learning", "q_learning_metrics.json"),
    ("Normal", "DQN", "dqn_metrics.json"),
    ("Peak Canteen", "A*", "astar_peak_canteen_metrics.json"),
    ("Peak Canteen", "Q-learning", "q_learning_peak_canteen_metrics.json"),
    ("Peak Canteen", "DQN", "dqn_peak_canteen_metrics.json"),
]


def load_json(filename):
    path = BASE_DIR / filename
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def mean(values):
    return sum(values) / len(values)


def all_same(values):
    return len(set(values)) == 1


def summarize_file(scenario, algorithm, filename):
    data = load_json(filename)
    rewards = data["rewards"]

    metric_lists = [
        rewards,
        data["avg_covered_per_episode"],
        data["sum_covered_per_episode"],
        data["avg_coverage_rate_per_episode"],
        data["move_steps_per_episode"],
        data["peak_covered_per_episode"],
    ]

    return {
        "场景": scenario,
        "算法": algorithm,
        "平均奖励": f"{mean(rewards):.2f}",
        "平均覆盖车辆数": f"{mean(data['avg_covered_per_episode']):.2f}",
        "累计覆盖车辆数": f"{mean(data['sum_covered_per_episode']):.2f}",
        "平均覆盖率": f"{mean(data['avg_coverage_rate_per_episode']):.4f}",
        "平均移动步数": f"{mean(data['move_steps_per_episode']):.2f}",
        "平均覆盖峰值": f"{mean(data['peak_covered_per_episode']):.2f}",
        "轮数": len(rewards),
        "是否完全一致": "True" if all(all_same(values) for values in metric_lists) else "False",
    }


def main():
    rows = [summarize_file(*item) for item in METRIC_FILES]
    headers = [
        "场景",
        "算法",
        "平均奖励",
        "平均覆盖车辆数",
        "累计覆盖车辆数",
        "平均覆盖率",
        "平均移动步数",
        "平均覆盖峰值",
        "轮数",
        "是否完全一致",
    ]

    print("Final Metrics Summary")
    print("-" * 132)
    print(
        f"{'Scenario':<15} {'Algorithm':<12} {'Reward':>10} "
        f"{'AvgCov':>10} {'SumCov':>10} {'CovRate':>10} "
        f"{'Moves':>10} {'PeakCov':>10} {'Episodes':>8} {'Same':>8}"
    )
    print("-" * 132)

    for row in rows:
        print(
            f"{row['场景']:<15} {row['算法']:<12} {row['平均奖励']:>10} "
            f"{row['平均覆盖车辆数']:>10} {row['累计覆盖车辆数']:>10} "
            f"{row['平均覆盖率']:>10} {row['平均移动步数']:>10} "
            f"{row['平均覆盖峰值']:>10} {row['轮数']:>8} "
            f"{row['是否完全一致']:>8}"
        )

    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)

    print("-" * 132)
    print(f"Saved {OUTPUT_CSV.name}")


if __name__ == "__main__":
    main()
