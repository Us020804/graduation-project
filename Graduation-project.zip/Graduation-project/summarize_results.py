import csv
import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
OUTPUT_CSV = BASE_DIR / "final_results_summary.csv"

FINAL_RESULTS = [
    ("Normal", "A*", "astar_rewards.json"),
    ("Normal", "Q-learning", "q_learning_eval_rewards.json"),
    ("Normal", "DQN", "dqn_eval_rewards.json"),
    ("Peak Canteen", "A*", "astar_peak_canteen_rewards.json"),
    ("Peak Canteen", "Q-learning", "q_learning_peak_canteen_eval_rewards.json"),
    ("Peak Canteen", "DQN", "dqn_peak_canteen_eval_rewards.json"),
]


def load_rewards(filename):
    path = BASE_DIR / filename
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def summarize_rewards(scenario, algorithm, filename):
    rewards = load_rewards(filename)
    all_same = len(set(rewards)) == 1
    return {
        "场景": scenario,
        "算法": algorithm,
        "平均奖励": f"{sum(rewards) / len(rewards):.2f}",
        "最大奖励": f"{max(rewards):.2f}",
        "最小奖励": f"{min(rewards):.2f}",
        "轮数": len(rewards),
        "是否完全一致": "True" if all_same else "False",
    }


def main():
    rows = [
        summarize_rewards(scenario, algorithm, filename)
        for scenario, algorithm, filename in FINAL_RESULTS
    ]

    headers = ["场景", "算法", "平均奖励", "最大奖励", "最小奖励", "轮数", "是否完全一致"]

    print("Final Results Summary")
    print("-" * 92)
    print(
        f"{'Scenario':<15} {'Algorithm':<12} {'Avg':>10} "
        f"{'Max':>10} {'Min':>10} {'Episodes':>8} {'Same':>8}"
    )
    print("-" * 92)
    for row in rows:
        print(
            f"{row['场景']:<15} {row['算法']:<12} {row['平均奖励']:>10} "
            f"{row['最大奖励']:>10} {row['最小奖励']:>10} "
            f"{row['轮数']:>8} {row['是否完全一致']:>8}"
        )

    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)

    print("-" * 92)
    print(f"Saved {OUTPUT_CSV.name}")


if __name__ == "__main__":
    main()
