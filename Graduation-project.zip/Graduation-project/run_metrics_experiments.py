import argparse
import json
from pathlib import Path

import torch

from astar import AStarPlanner
from dqn import DQNAgent
from env import UAVEnv
from q_learning import QLearningAgent


BASE_DIR = Path(__file__).resolve().parent
ACTIONS = ["UP", "DOWN", "LEFT", "RIGHT", "STAY"]

COMMON_ENV_KWARGS = {
    "uav_start": (1600, 1600),
    "uav_radius": 200,
    "step_size": 20,
    "x_min": 0,
    "x_max": 2938,
    "y_min": 0,
    "y_max": 2318,
    "max_steps": 50,
    "gui": False,
    "move_cost": 0.1,
}

SCENARIOS = {
    "Normal": {
        "sumocfg_file": "jnu_clean.sumocfg",
        "suffix": "",
        "q_table": "q_learning_q_table.pkl",
        "dqn_model": "dqn_best.pth",
    },
    "Peak Canteen": {
        "sumocfg_file": "jnu_peak_canteen.sumocfg",
        "suffix": "_peak_canteen",
        "q_table": "q_learning_peak_canteen_q_table.pkl",
        "dqn_model": "dqn_peak_canteen_best.pth",
    },
}


def build_dqn_state(env):
    uav_x, uav_y = env.get_state()
    vehicle_positions = env.get_vehicle_positions()
    covered_count = env.count_covered_vehicles()
    vehicle_count = len(vehicle_positions)

    if vehicle_positions:
        xs = [x for _, x, _ in vehicle_positions]
        ys = [y for _, _, y in vehicle_positions]
        center_x = sum(xs) / len(xs)
        center_y = sum(ys) / len(ys)
    else:
        center_x, center_y = uav_x, uav_y

    dx = center_x - uav_x
    dy = center_y - uav_y
    return (uav_x, uav_y, dx, dy, covered_count, vehicle_count)


def create_env(sumocfg_file):
    return UAVEnv(sumocfg_file=sumocfg_file, **COMMON_ENV_KWARGS)


def create_astar_planner():
    return AStarPlanner(
        x_min=COMMON_ENV_KWARGS["x_min"],
        x_max=COMMON_ENV_KWARGS["x_max"],
        y_min=COMMON_ENV_KWARGS["y_min"],
        y_max=COMMON_ENV_KWARGS["y_max"],
        step_size=COMMON_ENV_KWARGS["step_size"],
    )


def create_q_learning_agent(q_table_file):
    agent = QLearningAgent(
        actions=ACTIONS,
        alpha=0.1,
        gamma=0.9,
        epsilon=0.0,
    )
    agent.load_q_table(q_table_file)
    return agent


def create_dqn_agent(model_file):
    agent = DQNAgent(
        state_dim=6,
        action_dim=len(ACTIONS),
        actions=ACTIONS,
        lr=0.0005,
        gamma=0.9,
        epsilon_start=0.0,
        epsilon_min=0.0,
        epsilon_decay=1.0,
        batch_size=32,
        target_update=20,
        buffer_capacity=5000,
    )
    agent.q_net.load_state_dict(torch.load(model_file, map_location="cpu"))
    agent.target_net.load_state_dict(agent.q_net.state_dict())
    agent.q_net.eval()
    agent.target_net.eval()
    return agent


def record_step(env, step_index, action, reward):
    vehicle_positions = env.get_vehicle_positions()
    vehicle_count = len(vehicle_positions)
    covered_count = env.count_covered_vehicles()
    coverage_rate = covered_count / vehicle_count if vehicle_count else 0.0

    return {
        "step": step_index,
        "action": action,
        "reward": reward,
        "covered_count": covered_count,
        "vehicle_count": vehicle_count,
        "coverage_rate": coverage_rate,
        "move_step": action != "STAY",
    }


def summarize_episode(step_records):
    covered_counts = [item["covered_count"] for item in step_records]
    coverage_rates = [item["coverage_rate"] for item in step_records]
    move_steps = sum(1 for item in step_records if item["move_step"])

    return {
        "avg_covered": sum(covered_counts) / len(covered_counts),
        "sum_covered": sum(covered_counts),
        "avg_coverage_rate": sum(coverage_rates) / len(coverage_rates),
        "move_steps": move_steps,
        "peak_covered": max(covered_counts),
    }


def run_astar_episode(env, planner):
    env.reset()
    total_reward = 0.0
    step_records = []

    for step_index in range(1, env.max_steps + 1):
        vehicle_positions = env.get_vehicle_positions()
        uav_pos = env.get_state()
        action, _, _ = planner.choose_action(uav_pos, vehicle_positions)
        _, reward, done = env.step(action)

        total_reward += reward
        step_records.append(record_step(env, step_index, action, reward))

        if done:
            break

    return total_reward, step_records


def run_q_learning_episode(env, agent):
    state = env.reset()
    total_reward = 0.0
    step_records = []

    for step_index in range(1, env.max_steps + 1):
        action = agent.choose_best_action(state)
        next_state, reward, done = env.step(action)

        total_reward += reward
        step_records.append(record_step(env, step_index, action, reward))
        state = next_state

        if done:
            break

    return total_reward, step_records


def run_dqn_episode(env, agent):
    env.reset()
    state = build_dqn_state(env)
    total_reward = 0.0
    step_records = []

    for step_index in range(1, env.max_steps + 1):
        action, _ = agent.choose_action(state)
        _, reward, done = env.step(action)
        next_state = build_dqn_state(env)

        total_reward += reward
        step_records.append(record_step(env, step_index, action, reward))
        state = next_state

        if done:
            break

    return total_reward, step_records


def build_output(scenario_name, algorithm, sumocfg_file, rewards, episodes, step_records_by_episode):
    return {
        "scenario": scenario_name,
        "algorithm": algorithm,
        "sumocfg_file": sumocfg_file,
        "episodes": len(rewards),
        "max_steps": COMMON_ENV_KWARGS["max_steps"],
        "uav_radius": COMMON_ENV_KWARGS["uav_radius"],
        "step_size": COMMON_ENV_KWARGS["step_size"],
        "move_cost": COMMON_ENV_KWARGS["move_cost"],
        "rewards": rewards,
        "avg_covered_per_episode": [item["avg_covered"] for item in episodes],
        "sum_covered_per_episode": [item["sum_covered"] for item in episodes],
        "avg_coverage_rate_per_episode": [item["avg_coverage_rate"] for item in episodes],
        "move_steps_per_episode": [item["move_steps"] for item in episodes],
        "peak_covered_per_episode": [item["peak_covered"] for item in episodes],
        "step_records": step_records_by_episode,
    }


def run_case(scenario_name, scenario, algorithm, episodes):
    env = create_env(scenario["sumocfg_file"])

    if algorithm == "A*":
        runner = lambda: run_astar_episode(env, create_astar_planner())
    elif algorithm == "Q-learning":
        agent = create_q_learning_agent(BASE_DIR / scenario["q_table"])
        runner = lambda: run_q_learning_episode(env, agent)
    elif algorithm == "DQN":
        agent = create_dqn_agent(BASE_DIR / scenario["dqn_model"])
        runner = lambda: run_dqn_episode(env, agent)
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

    rewards = []
    episode_summaries = []
    step_records_by_episode = []

    try:
        for episode_index in range(1, episodes + 1):
            total_reward, step_records = runner()
            rewards.append(total_reward)
            episode_summaries.append(summarize_episode(step_records))
            step_records_by_episode.append(step_records)
            print(
                f"  Episode {episode_index}: reward={total_reward:.2f}, "
                f"avg_covered={episode_summaries[-1]['avg_covered']:.2f}, "
                f"coverage_rate={episode_summaries[-1]['avg_coverage_rate']:.4f}"
            )
    finally:
        env.close_sumo()

    return build_output(
        scenario_name,
        algorithm,
        scenario["sumocfg_file"],
        rewards,
        episode_summaries,
        step_records_by_episode,
    )


def output_name(algorithm, suffix):
    prefix = {
        "A*": "astar",
        "Q-learning": "q_learning",
        "DQN": "dqn",
    }[algorithm]
    return f"{prefix}{suffix}_metrics.json"


def main():
    parser = argparse.ArgumentParser(
        description="Run final evaluation experiments and collect step-level metrics."
    )
    parser.add_argument("--episodes", type=int, default=30)
    parser.add_argument(
        "--rerun",
        action="store_true",
        help="Recreate metrics files even if they already exist.",
    )
    args = parser.parse_args()

    for scenario_name, scenario in SCENARIOS.items():
        for algorithm in ["A*", "Q-learning", "DQN"]:
            filename = output_name(algorithm, scenario["suffix"])
            output_path = BASE_DIR / filename

            if output_path.exists() and not args.rerun:
                print(f"[SKIP] {scenario_name} - {algorithm}: found {filename}")
                continue

            print(f"[RUN] {scenario_name} - {algorithm}")
            data = run_case(scenario_name, scenario, algorithm, args.episodes)

            with output_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            avg_reward = sum(data["rewards"]) / len(data["rewards"])
            print(f"[SAVED] {filename}: average_reward={avg_reward:.2f}")


if __name__ == "__main__":
    main()
