import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


BASE_DIR = Path(__file__).resolve().parent

FINAL_RESULTS = {
    "Normal": {
        "A*": "astar_rewards.json",
        "Q-learning": "q_learning_eval_rewards.json",
        "DQN": "dqn_eval_rewards.json",
    },
    "Peak Canteen": {
        "A*": "astar_peak_canteen_rewards.json",
        "Q-learning": "q_learning_peak_canteen_eval_rewards.json",
        "DQN": "dqn_peak_canteen_eval_rewards.json",
    },
}

TRAINING_RESULTS = {
    "Q-learning": {
        "Normal": "q_learning_rewards.json",
        "Peak Canteen": "q_learning_peak_canteen_rewards.json",
    },
    "DQN": {
        "Normal": "dqn_rewards.json",
        "Peak Canteen": "dqn_peak_canteen_rewards.json",
    },
}


def load_rewards(filename):
    path = BASE_DIR / filename
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def average(values):
    return sum(values) / len(values)


def moving_average(values, window=5):
    result = []
    for index in range(len(values)):
        start = max(0, index - window + 1)
        result.append(average(values[start:index + 1]))
    return result


def save_bar_for_scenario(scenario, output_name):
    algorithms = list(FINAL_RESULTS[scenario].keys())
    means = [
        average(load_rewards(FINAL_RESULTS[scenario][algorithm]))
        for algorithm in algorithms
    ]

    plt.figure(figsize=(8, 5))
    bars = plt.bar(algorithms, means, color=["#4C78A8", "#F58518", "#54A24B"])
    plt.title(f"{scenario} Scenario")
    plt.xlabel("Algorithm")
    plt.ylabel("Average Total Reward")
    plt.grid(axis="y", linestyle="--", alpha=0.4)

    for bar, value in zip(bars, means):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=10,
        )

    plt.tight_layout()
    plt.savefig(BASE_DIR / output_name, dpi=300)
    plt.close()
    print(f"Saved {output_name}")


def save_grouped_scenario_bar(output_name):
    algorithms = ["A*", "Q-learning", "DQN"]
    normal_means = [
        average(load_rewards(FINAL_RESULTS["Normal"][algorithm]))
        for algorithm in algorithms
    ]
    peak_means = [
        average(load_rewards(FINAL_RESULTS["Peak Canteen"][algorithm]))
        for algorithm in algorithms
    ]

    x_positions = list(range(len(algorithms)))
    width = 0.35

    plt.figure(figsize=(9, 5.5))
    plt.bar(
        [x - width / 2 for x in x_positions],
        normal_means,
        width=width,
        label="Normal",
        color="#4C78A8",
    )
    plt.bar(
        [x + width / 2 for x in x_positions],
        peak_means,
        width=width,
        label="Peak Canteen",
        color="#F58518",
    )
    plt.xticks(x_positions, algorithms)
    plt.title("Normal vs Peak Canteen")
    plt.xlabel("Algorithm")
    plt.ylabel("Average Total Reward")
    plt.legend()
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(BASE_DIR / output_name, dpi=300)
    plt.close()
    print(f"Saved {output_name}")


def save_training_curve(algorithm, output_name):
    plt.figure(figsize=(10, 5.5))

    for scenario, filename in TRAINING_RESULTS[algorithm].items():
        rewards = load_rewards(filename)
        episodes = list(range(1, len(rewards) + 1))
        plt.plot(episodes, rewards, linewidth=1.2, alpha=0.35, label=f"{scenario} Reward")
        plt.plot(
            episodes,
            moving_average(rewards, window=5),
            linewidth=2.2,
            label=f"{scenario} MA(5)",
        )

    plt.title(f"{algorithm} Training Curve")
    plt.xlabel("Episode")
    plt.ylabel("Total Reward")
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.savefig(BASE_DIR / output_name, dpi=300)
    plt.close()
    print(f"Saved {output_name}")


def main():
    save_bar_for_scenario("Normal", "final_normal_algorithm_bar.png")
    save_bar_for_scenario("Peak Canteen", "final_peak_canteen_algorithm_bar.png")
    save_grouped_scenario_bar("final_normal_vs_peak_grouped_bar.png")
    save_training_curve("Q-learning", "final_q_learning_training_curve.png")
    save_training_curve("DQN", "final_dqn_training_curve.png")


if __name__ == "__main__":
    main()
